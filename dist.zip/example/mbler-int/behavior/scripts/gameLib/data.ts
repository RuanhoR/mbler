// Type definitions for Minecraft effects and damage causes
export interface MinecraftEffect {
  key: string;
  name: string;
}

export interface DamageCause {
  cause: string;
  description: string;
}

export const EffectList: Record<string, string> = {
  "absorption": "伤害吸收",
  "bad_omen": "不祥之兆",
  "blindness": "失明",
  "conduit_power": "潮涌能量",
  "darkness": "黑暗",
  "fatal_poison": "中毒（致命）",
  "fire_resistance": "抗火",
  "haste": "急迫",
  "health_boost": "生命提升",
  "hunger": "饥饿",
  "infested": "寄生",
  "instant_damage": "瞬间伤害",
  "instant_health": "瞬间治疗",
  "invisibility": "隐身",
  "jump_boost": "跳跃提升",
  "levitation": "飘浮",
  "mining_fatigue": "挖掘疲劳",
  "nausea": "反胃",
  "night_vision": "夜视",
  "oozing": "渗浆",
  "poison": "中毒",
  "raid_omen": "袭击之兆",
  "regeneration": "生命恢复",
  "resistance": "抗性提升",
  "saturation": "饱和",
  "slow_falling": "缓降",
  "slowness": "缓慢",
  "speed": "迅捷",
  "strength": "力量",
  "trial_omen": "试炼之兆",
  "village_hero": "村庄英雄",
  "water_breathing": "水下呼吸",
  "weakness": "虚弱",
  "weaving": "盘丝",
  "wind_charged": "蓄风",
  "wither": "凋零"
};

export const EntityDamageCause: Record<string, string> = {
  "anvil": " 由铁砧坠落造成的伤害。",
  "blockExplosion": "非实体爆炸造成的伤害，比如床的爆炸。",
  "campfire": "由篝火引起的伤害。",
  "contact": "由与实体或方块进行物理接触所造成的伤害，例如触碰甜莓灌木丛或河豚。",
  "drowning": "实体在缺氧且位于液体方块中时受到的伤害。",
  "entityAttack": "实体攻击所引起的伤害。",
  "entityExplosion": "由实体爆炸（如 creeper 或 Wither）造成的伤害。",
  "fall": "从高处坠落时对地面造成的伤害。",
  "fallingBlock": "由坠落方块造成的伤害。请注意，重锤和钟乳石具有各自独立伤害原因。",
  "fire": "因着火而受到的伤害。",
  "fireTick": "因长时间燃烧而受到的伤害。",
  "fireworks": "烟花引起的伤害。",
  "flyIntoWall": "使用鞘翅高速飞行时撞墙导致的伤害。",
  "freezing": "因停留在粉末雪方块中而受到的伤害。",
  "lava": "接触岩浆方块所造成的伤害。",
  "lightning": "因被闪电击中而受到的伤害。",
  "magic": "由魔法攻击引起的伤害，比如诱魔之牙或传导块。",
  "magma": "触摸熔岩所造成的伤害。",
  "none": "由无直接源造成伤害，例如命令或脚本中的伤害。",
  "override": "由间接原因造成的伤害。比如，通过行为包将生物的生命值设置为 0。",
  "piston": "活塞造成的伤害。",
  "projectile": "由投射物引起的伤害。",
  "ramAttack": "山羊顶撞引起的伤害。",
  "selfDestruct": "由/kill 命令导致伤害。",
  "sonicBoom": "由坚守者的声波攻击所造成的伤害。",
  "soulCampfire": "由灵魂篝火引起的伤害。",
  "stalactite": "由钟乳石块坠落造成的伤害。",
  "stalagmite": "踩石钟乳方块所造成的伤害。",
  "starve": "长时间饥饿导致伤害。",
  "suffocation": "实体在缺氧且位于非液体方块中时受到的伤害。",
  "temperature": "实体处于不适宜的气候中受到的伤害。比如，在温度超过 1 度的环境中，雪人会受到伤害。",
  "thorns": "由荆棘盔甲附魔或守卫的荆棘效果所造成的伤害。",
  "void": "从虚空跌落时产生的持续伤害。",
  "wither": "由凋零效果引起的伤害。比如，触碰凋零玫瑰。"
};